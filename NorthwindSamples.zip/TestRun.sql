-- **************************************************************************************
-- Northwind OLTP Database Reset
-- **************************************************************************************
-- Force Polling to execute
USE Northwind
GO
TRUNCATE TABLE DataWarehouse.DWPolling
GO
INSERT INTO DataWarehouse.DWPolling(ReferenceSchema,ReferenceTable)
VALUES('Companies','Customers'),
		   ('Companies','Employees'),
		   ('Companies','Shippers'),
		   ('Companies','Suppliers'),
		   ('Products','Products'),		
		   ('Products','Categories')
GO   

UPDATE DataWarehouse.DWPolling
SET UpdateOn = ' 1 january 1900'
GO

SELECT *
FROM DataWarehouse.DWPolling
-- **************************************************************************************

-- **************************************************************************************
-- Northwind DW Reset
-- **************************************************************************************
Use Northwind_DW
go
-- Test Run

TRUNCATE TABLE DWPROC.ETLStepExecutionLog
GO
DELETE FROM DWPROC.ETLExecution
GO
DELETE FROM DWPROC.SnapshotDataChanges
GO

DELETE FROM Staging.Fact_OrderDetails
GO
DELETE FROM Staging.Fact_Orders
GO
DELETE FROM Staging.Dim_Shippers
GO
DELETE FROM Staging.Dim_Products
GO
DELETE FROM Staging.Dim_Employees
GO
DELETE FROM Staging.Dim_Customers
GO
DELETE FROM Staging.Dim_Categories
GO
DELETE FROM Staging.Dim_Suppliers
GO

DELETE FROM Enterprise.Fact_OrderDetails
GO
DELETE FROM Enterprise.Fact_Orders
GO
DELETE FROM Enterprise.Dim_Shippers
GO
DELETE FROM Enterprise.Dim_Products
GO
DELETE FROM Enterprise.Dim_Employees
GO
DELETE FROM Enterprise.Dim_Customers
GO
DELETE FROM Enterprise.Dim_Categories
GO
DELETE FROM Enterprise.Dim_Suppliers
GO

DELETE FROM DataMart.Fact_OrderDetails
GO
DELETE FROM DataMart.Dim_Customers
GO
DELETE FROM DataMart.Dim_Employees
GO
DELETE FROM DataMart.Dim_Products
GO
DELETE FROM DataMart.Dim_Suppliers
GO
DELETE FROM DataMart.Dim_Categories
GO

-- Create the NULL replacement records for all dimensions
-- [Enterprise].[Dim_Categories]
SET IDENTITY_INSERT [Enterprise].[Dim_Categories] ON
INSERT INTO [Enterprise].[Dim_Categories]([CategoryID_Key],[CategoryID],[CategoryName])
VALUES(-1,-1,'No Category')
SET IDENTITY_INSERT [Enterprise].[Dim_Categories] OFF
GO
-- [Enterprise].[Dim_Shippers]
SET IDENTITY_INSERT [Enterprise].[Dim_Shippers] ON
INSERT INTO [Enterprise].[Dim_Shippers]([ShipperID_Key],[ShipperID],[CompanyName],[Phone])
VALUES(-1,-1,'No Shipper','N/A')
SET IDENTITY_INSERT [Enterprise].[Dim_Shippers] OFF
GO

-- [Enterprise].[Dim_Suppliers]
SET IDENTITY_INSERT [Enterprise].[Dim_Suppliers] ON
INSERT INTO [Enterprise].[Dim_Suppliers]([SupplierID_Key],[SupplierID],[CompanyName],[ContactName],[ContactTitle],
										[Address],[City],[Region],[PostalCode],[Country],[Phone],[Fax])
VALUES(-1,-1,'No Supplier','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A')
SET IDENTITY_INSERT [Enterprise].[Dim_Suppliers] OFF
GO

-- [Enterprise].[Dim_Products]
SET IDENTITY_INSERT [Enterprise].[Dim_Products] ON
INSERT INTO [Enterprise].[Dim_Products]([ProductID_Key],[ProductID],[ProductName],[CategoryID_Key],[SupplierID_Key],
										[QuantityPerUnit],[UnitPrice],[UnitsInStock],[UnitsOnOrder],
										[ReorderLevel],[Discontinued])
VALUES(-1,-1,'No Product',-1,-1,'N/A',0,0,0,0,0)
SET IDENTITY_INSERT [Enterprise].[Dim_Products] OFF
GO

-- [Enterprise].[Dim_Customers]
SET IDENTITY_INSERT [Enterprise].[Dim_Customers] ON
INSERT INTO [Enterprise].[Dim_Customers]([CustomerID_Key],[CustomerID],[CompanyName],[ContactName],[ContactTitle],
										 [Address],[City],[Region],[PostalCode],[Country],[Phone],[Fax],[Rating])
VALUES(-1,-1,'No Customer','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A',0)
SET IDENTITY_INSERT [Enterprise].[Dim_Customers] OFF
GO

-- [Enterprise].[Dim_Employees]
SET IDENTITY_INSERT [Enterprise].[Dim_Employees] ON
INSERT INTO [Enterprise].[Dim_Employees]([EmployeeID_Key],[EmployeeID],[Lastname],[FirstName],[Title],[TitleOfCourtesy],
										 [BirthDate],[HireDate],[Address],[City],[Region],[PostalCode],
										 [Country],[HomePhone],[Extension],[Photo],[ReportsTo])
VALUES(-1,-1,'No Employee','N/A','N/A','N/A','1990-01-01','1990-01-01','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A',0)
SET IDENTITY_INSERT [Enterprise].[Dim_Employees] OFF
GO

UPDATE DWPROC.ETLStep
SET LastUpdatedOn = '1 january 1900'
WHERE DWLayer = 'Staging'
GO

-- **************************************************************************************